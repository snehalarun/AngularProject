let arr1=[2,3,4,5,6,];
let arr2=['snehal','snowy',"siya"];
let arr3=[];
let arr4:any=['Python',87.90,45,"Snehal"];
console.log("****************************display array elements*****************")
console.log(arr1);
console.log("display array using join()"+arr2.join());
console.log("display array using join()"+arr2.join(' '));
console.log("display array using join()"+arr2.join('&'));

console.log("***********using foreach loop*********")
arr4.forEach((val,i)=>{
    console.log("Value ="+val+" & index= "+i)
})

console.log("*************************")
arr1.forEach((val,i)=>{
    console.log("Number ="+val+" & index= "+i)
})
console.log("***********1using rest parameter function*********")
function show(num1:number,num2:number,...num:number[]){
    console.log(num);
}
show(34,78);
show(45,78,89);

console.log("***********2using rest parameter function*********")
function show2(...num:number[]){
    console.log(num);
}
show2();
show2(67,890,789,65,45,34);
show2(45,67);

console.log("**************************Using Push&Pop******************")
let str:string[]=[];
str.push('7008');
console.log(str);
str.push('sss','ttt','aaa');
console.log(str);
let result1=str.pop();
console.log(str);
console.log("Poped data is "+result1)
let result2=str.pop();
console.log(str);
console.log("Poped data is "+result2);


