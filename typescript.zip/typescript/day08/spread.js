var arr1 = [2, 3, 4, 5, 6,];
var arr2 = ['snehal', 'snowy', "siya"];
var arr3 = [];
var arr4 = ['Python', 87.90, 45, "Snehal"];
console.log("****************************display array elements*****************");
console.log(arr1);
console.log("display array using join()" + arr2.join());
console.log("display array using join()" + arr2.join(' '));
console.log("display array using join()" + arr2.join('&'));
console.log("***********using foreach loop*********");
arr4.forEach(function (val, i) {
    console.log("Value =" + val + " & index= " + i);
});
console.log("*************************");
arr1.forEach(function (val, i) {
    console.log("Number =" + val + " & index= " + i);
});
console.log("***********1using rest parameter function*********");
function show(num1, num2) {
    var num = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        num[_i - 2] = arguments[_i];
    }
    console.log(num);
}
show(34, 78);
show(45, 78, 89);
console.log("***********2using rest parameter function*********");
function show2() {
    var num = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        num[_i] = arguments[_i];
    }
    console.log(num);
}
show2();
show2(67, 890, 789, 65, 45, 34);
show2(45, 67);
console.log("**************************Using Push&Pop******************");
var str = [];
str.push('7008');
console.log(str);
str.push('sss', 'ttt', 'aaa');
console.log(str);
var result1 = str.pop();
console.log(str);
console.log("Poped data is " + result1);
var result2 = str.pop();
console.log(str);
console.log("Poped data is " + result2);
