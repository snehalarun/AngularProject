console.log("***********control statement************");
//if,if-else,if-else ladder,switch,break,continue
var a = 21;
// if(a<4){
//     console.log("Condition is true");
// }else{
//     console.log("Condition is false");
// }
var choice = 21;
// switch(choice){
//     case 1: console.log("u rin case 1")
//             break;
//     case 2: console.log("u rin case 2")
//             break;
//     default:console.log("u r in Default case")
//             break;
// }
// Loop Statement
// while,do-while,for,foreach
var count = 5;
// while(count!=0){
//     console.log("Count is "+count);
//     count--;
// }
// do{
//     console.log("Count is "+count);
//     count--;
// }while(count!=0)
//for loop
// for(var i:number=0;i<4;i++){
//     console.log("Value of i "+i);
// }
// console.log("Value of i after the loop "+i);
//var has global scope 
// let 
// scope => within nearest block({})
for (var i = 0; i < 4; i++) {
    console.log("Value of i " + i);
}
// console.log("Value of i after the loop "+i);
// let a1;
//const
// u can assign a const(final) value 
// it has global as well as local scope 
var pi = 3.14;
