var add = function (a, b) {
    console.log("Sum:" + (a + b));
};
add(10, 20);
