var s = function (a, b) {
    console.log("Sum:" + (a + b));
};
s(10, 20);
