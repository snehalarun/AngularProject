
let add=function (a:number,b:number)
{
    console.log("Sum:"+(a+b));

}
add(10,20);