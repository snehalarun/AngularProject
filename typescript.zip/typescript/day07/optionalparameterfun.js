console.log("************************ Optional parameter function*******************");
function add1(a, b) {
    console.log("Value of A is " + a); // 10
    console.log("Value of B is " + b); //undefined
    console.log("Addition  of A+B is " + (a + b)); //NAN => Not a number
}
//add1(10);
add1(10, 20);
function add2(a, b) {
    console.log("Value of A is " + a); // 10
    console.log("Value of B is " + b); //undefined
    console.log("Addition  of A+B is " + (a + b)); //NAN => Not a number
}
// add2();
add2(45, 50);
