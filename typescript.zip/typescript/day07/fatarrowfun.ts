console.log("************Fat arrow function/Arrow function **************")
// it is advanced version of Anonymous function
var temp3 = function () {
    console.log("Fat arrow function is called ");
};
// temp3();
var temp4 = function (a, b) {
    return (a + b);
};
console.log(`
        Addition is ${temp4(7,10)}
`);
