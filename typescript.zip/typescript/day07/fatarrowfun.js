console.log("************Fat arrow function/Arrow function **************");
// it is advanced version of Anonymous function
var temp3 = function () {
    console.log("Fat arrow function is called ");
};
// temp3();
var temp4 = function (a, b) {
    return (a + b);
};
console.log("\n        Addition is ".concat(temp4(7, 10), "\n"));
