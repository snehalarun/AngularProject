console.log("**********Anonymous function**************");
// function does not having any name 
var temp1 = function () {
    console.log("first type of Anonymous function is called ");
};
temp1();
var temp2 = function (a, b) {
    return (a + b);
};
console.log(temp2(4, 5));
