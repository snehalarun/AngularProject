console.log("*****************default parameter function*************");
function add3(a, b) {
    if (b === void 0) { b = 2; }
    console.log("Value of A is " + a); // 10
    console.log("Value of B is " + b); //undefined
    console.log("Addition  of A+B is " + (a + b)); //NAN => Not a number
}
 add3(10,45);
function add4(a, b) {
    if (a === void 0) { a = 9; }
    console.log("Value of A is " + a); // 10
    console.log("Value of B is " + b); //undefined
    console.log("Addition  of A+B is " + (a + b)); //NAN => Not a number
}
 add4(7,8);
function add5(a, b) {
    if (a === void 0) { a = 9; }
    console.log("Value of A is " + a); // 10
    console.log("Value of B is " + b); //undefined
    console.log("Addition  of A+B is " + (a + b)); //NAN => Not a number
}
//add5();
add5(45,89);
function add6(a:number=5, b?:number) {
    console.log(a);
    console.log(b);
    console.log(a!+b!)
}
add6(7,8);
add6(10);