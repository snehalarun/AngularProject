import { Circle } from "./Circle";
import {Rectangle} from "./Rectangle";

let circleobj= new Circle(4.5)
circleobj.MyArea();
circleobj.display();

let recobj=new Rectangle(4,5)
recobj.MyArea();
recobj.display();