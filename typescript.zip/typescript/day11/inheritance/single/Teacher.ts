import { Person } from "./Person";
class Teacher extends Person
{
    payment:number;
    constructor(name:string,payment:number){
        super(name);
        this.name=name;
        this.payment=payment;
    }
    display():void{
        console.log(`
        Teachers Name::${this.name}`)
        console.log(`
        Teachers Payment::${this.payment}`)
    }
}
let obj=new Teacher("Snehal Wakchaure",56000)
obj.display();