import { Car } from "./Car";
class CarModel extends Car{
    Model():void{
        console.log("Mahindra2022")
    }
}
let obj=new CarModel();
obj.Type();
obj.Brand();
obj.Model();