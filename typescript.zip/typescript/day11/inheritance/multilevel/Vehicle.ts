export class Vehicle{
    Type():void{
        console.log("Car")
    }
}