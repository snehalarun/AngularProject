"use strict";
exports.__esModule = true;
exports.Vehicle = void 0;
var Vehicle = /** @class */ (function () {
    function Vehicle() {
    }
    Vehicle.prototype.Type = function () {
        console.log("Car");
    };
    return Vehicle;
}());
exports.Vehicle = Vehicle;
