export class Shape{
    MyArea(){
    console.log("You are in Shape class")
    }
}
