import { Shape } from "./Shape";

export class Circle extends Shape{
    radius:number;
    area:number;
    
    constructor(r:number){
        super();
        this.radius=r;
        this.area=0
    }
    override MyArea(): void {
        this.area=3.14*this.radius*this.radius;
        
    }
    display(){
        console.log(`
        --------------Area of circle-------------
        Radius=${this.radius}
        Area=${this.area}`)
    }
}