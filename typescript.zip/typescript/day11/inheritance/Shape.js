"use strict";
exports.__esModule = true;
exports.Shape = void 0;
var Shape = /** @class */ (function () {
    function Shape() {
    }
    Shape.prototype.MyArea = function () {
        console.log("You are in Shape class");
    };
    return Shape;
}());
exports.Shape = Shape;
