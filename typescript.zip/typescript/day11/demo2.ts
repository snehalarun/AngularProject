import { Demo,add,pi} from "./demo1";

// let demoobj=new Demo(9,"Snehal","Wakchaure");

// demoobj.display();

// console.log(`
// Addition is ${add(6,8)}`);

// console.log(`Value of pi =${pi}`)