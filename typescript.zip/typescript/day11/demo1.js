"use strict";
exports.__esModule = true;
exports.pi = exports.add = exports.Demo = void 0;
var Demo = /** @class */ (function () {
    function Demo(id, fname, lname) {
        this.id = id;
        this.fname = fname;
        this.lname;
    }
    Demo.prototype.display = function () {
        console.log("\n        ID->".concat(this.id, "\n        First Name->").concat(this.fname, "\n        Last Name->").concat(this.lname));
    };
    return Demo;
}());
exports.Demo = Demo;
function add(a, b) {
    return a + b;
}
exports.add = add;
exports.pi = 3.14;
