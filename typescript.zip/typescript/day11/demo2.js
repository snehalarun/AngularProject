"use strict";
exports.__esModule = true;
var demo1_1 = require("./demo1");
var demoobj = new demo1_1.Demo(9, "Snehal", "Wakchaure");
demoobj.display();
console.log("\nAddition is ".concat((0, demo1_1.add)(6, 8)));
console.log("Value of pi =".concat(demo1_1.pi));
