export class Demo{
    public id:number;
    private fname:string;
    protected lname:string;

    constructor(id:number,fname:string,lname:string){
        this.id=id;
        this.fname=fname;
        this.lname;
    }

    display(){
        console.log(`
        ID->${this.id}
        First Name->${this.fname}
        Last Name->${this.lname}`)
    }
} 
export function add(a:number,b:number):number
{
    return a+b;
}
export let pi=3.14;