
console.log("Hello world...");
console.log('welcome to my Tutorial')
console.log(`I have enjoy Angular12 Module`);
console.log("Hello World..");
console.log('Welcome to Angular 12 Module');
console.log("\n            Hopes so u r enjoying Module..\n");
console.log("Hello World..")
console.log('Welcome to Angular 12 Module')
console.log(`
            Hopes so u r enjoying Module..
`)