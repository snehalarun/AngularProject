class Demo{

    id:number;
    name:string;
    mark:number;
    constructor(i:number,n:string,m:number){
        this.id=i;
        this.name=n;
        this.mark=m;
    }
    display(){
        console.log(`
        ID->${this.id}
        Name->${this.name}
        Mark->${this.mark}`)
    }
}
let obj=new Demo(16321,"Snehal Wakchaure",85.95);
obj.display();