class Myclass{
    id:number;
    name:string;
    marks:number;
    constructor(){

    }
    display(){
        console.log(`
        ID::${this.id}
        Name::${this.name}
        Marks::${this.marks}
        `)

    }
}
let classohj=new Myclass();
classohj.display();