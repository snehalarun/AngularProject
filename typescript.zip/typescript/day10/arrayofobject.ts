//Array of object
let arrobj=[{
    id:9,
    fname:"Snehal",
    lname:'Wakchaure',
    country:{
        cid:32,
        cname:"US"
    },
    month:['sep','oct','nov','dec'],
    result:[{
        sub:"M2",
        marks:86

    }]

},
{
    id:19,
    fname:"Arun",
    "lname":'Wakchaure',
    country:{
        cid:22,
        cname:"India"
    },
    month:['jan','feb','mar','apr'],
    result:[{
        sub:"M3",
        marks:76

    }]

},
{
    id:29,
    fname:"Akshay",
    "lname":'Wakchaure',
    country:{
        cid:12,
        cname:"Dubai"
    },
    month:['may','jun','jul','aug'],
    result:[{
        sub:"M1",
        marks:56

    }]


},
{
    id:39,
    fname:"Sushila",
    "lname":'Wakchaure',
    country:{
        cid:2,
        cname:"India"
    },
    month:['sep','oct','nov','dec'],
    result:[{
        sub:"M4",
        marks:66

    }]

}
]
for(let i=0;i<arrobj.length;i++){
    console.log(`
    ID=>${arrobj[i].id}
    First Name=>${arrobj[i].fname}
    Last Name=>${arrobj[i].lname}
    Country Name=>${arrobj[i].country?.cname}
    Month=>${arrobj[i].month.join(" ")}
    -----------------Result------------------
    `);
    for(let j=0;j<arrobj[i].result.length;j++){
        console.log(`
                    Subject=>${arrobj[i].result[j].sub}
                    Marks=>${arrobj[i].result[j].marks}`)
    }
}
let a=[[2,3],[4,5],[6,7]]
for(let i=0;i<a.length;i++)
{
    console.log(`${a[i]}`)
}
arrobj.forEach(element => {
    
});