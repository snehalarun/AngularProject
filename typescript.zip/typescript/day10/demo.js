var Myclass = /** @class */ (function () {
    function Myclass(id, n, m) {
        this.id = id;
        this.name = n;
        this.marks = m;
    }
    Myclass.prototype.display = function () {
        console.log("\n        ID::".concat(this.id, "\n        Name::").concat(this.name, "\n        Marks::").concat(this.marks, "\n        "));
    };
    return Myclass;
}());
var classohj = new Myclass();
classohj.display();
