var Demo = /** @class */ (function () {
    function Demo(i, n, m) {
        this.id = i;
        this.name = n;
        this.mark = m;
    }
    Demo.prototype.display = function () {
        console.log("\n        ID->".concat(this.id, "\n        Name->").concat(this.name, "\n        Mark->").concat(this.mark));
    };
    return Demo;
}());
var obj = new Demo(16321, "Snehal Wakchaure", 85.95);
obj.display();
