var _a;
//Array of object
var arrobj = [{
        id: 9,
        fname: "Snehal",
        lname: 'Wakchaure',
        country: {
            cid: 32,
            cname: "US"
        },
        month: ['sep', 'oct', 'nov', 'dec'],
        result: [{
                sub: "M2",
                marks: 86
            }]
    },
    {
        id: 19,
        fname: "Arun",
        "lname": 'Wakchaure',
        country: {
            cid: 22,
            cname: "India"
        },
        month: ['jan', 'feb', 'mar', 'apr'],
        result: [{
                sub: "M3",
                marks: 76
            }]
    },
    {
        id: 29,
        fname: "Akshay",
        "lname": 'Wakchaure',
        country: {
            cid: 12,
            cname: "Dubai"
        },
        month: ['may', 'jun', 'jul', 'aug'],
        result: [{
                sub: "M1",
                marks: 56
            }]
    },
    {
        id: 39,
        fname: "Sushila",
        "lname": 'Wakchaure',
        country: {
            cid: 2,
            cname: "India"
        },
        month: ['sep', 'oct', 'nov', 'dec'],
        result: [{
                sub: "M4",
                marks: 66
            }]
    }
];
for (var i = 0; i < arrobj.length; i++) {
    console.log("\n    ID=>".concat(arrobj[i].id, "\n    First Name=>").concat(arrobj[i].fname, "\n    Last Name=>").concat(arrobj[i].lname, "\n    Country Name=>").concat((_a = arrobj[i].country) === null || _a === void 0 ? void 0 : _a.cname, "\n    Month=>").concat(arrobj[i].month.join(" "), "\n    -----------------Result------------------\n    "));
    for (var j = 0; j < arrobj[i].result.length; j++) {
        console.log("\n                    Subject=>".concat(arrobj[i].result[j].sub, "\n                    Marks=>").concat(arrobj[i].result[j].marks));
    }
}
var a = [[2, 3], [4, 5], [6, 7]];
for (var i = 0; i < a.length; i++) {
    console.log("".concat(a[i]));
}
arrobj.forEach(function (element) {
});
