
// console.log(35c - 30);
// var a;
// var a_c;
// var a$f23,df3_Gg3;


var a1:number=40;
console.log("Value of a1 is "+a1);
console.log('Value of a1 is '+a1);
console.log(`value of a1 is ${a1}`+a1);
console.log(`value of a1 is `+(a1+a1));

var a2!:any;
console.log("any datatype Value of a2 is "+a2);
var a3!:number;
console.log("number datatype Value of a5 is "+a3);
var a4!:void;
console.log("Value of a4 is "+a4);
var a5!:string;
console.log("Value of a5 is "+a5);
var s:any;
var tmp=s as string;
console.log(tmp.length);
var tmp1=<number> s;
console.log(tmp1.toString);