import { Demo,add,pi } from "../day11/demo1";
let obj=new Demo(3,"fgfd","hth");
obj.display();

console.log(`
Addition is ${add(6,8)}`);

console.log(`Value of pi =${pi}`)