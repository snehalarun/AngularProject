console.log("*************Splice Method*******************");
var ar = ['Core Java', "Advance Java", "Spring Boot", 'Angular 12', 'JSP', 'Jenkings', "Docker", "AWS"];
var tmp = str.slice(1, 7);
console.log(tmp);
