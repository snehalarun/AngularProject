//
var jsonobj = {
    id: 4,
    fname: "snehal",
    "lname": 'wakchaure',
    cgpa: 9.5
};
console.log(jsonobj);
console.log("************************1.Using dot operator*************************");
console.log("First Name::".concat(jsonobj.fname, "\n             Last Name ::").concat(jsonobj.lname, "\n             ID::").concat(jsonobj.id, "\n             CGPA::").concat(jsonobj.cgpa));
console.log("************************1.Using square operator*************************");
console.log("First Name::".concat(jsonobj["fname"], "\n             Last Name ::").concat(jsonobj["lname"], "\n             ID::").concat(jsonobj["id"], "\n             CGPA::").concat(jsonobj["cgpa"]));
