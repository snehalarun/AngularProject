//json object JavaScript Object Notation
//Data is in key-value pair format
// {
//     'id':56,
//     'name':"snehal",
//     'marks':85.95
// }