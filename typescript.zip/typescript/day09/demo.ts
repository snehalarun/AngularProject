console.log("**************Slice method************************")
let a:number[]=[10,20,30,40,50]
console.log("Display array:"+a)
console.log("add 3rd index element is 100")
a.splice(3,0,100)
console.log(a)
console.log("add 2nd  index element of 2 element add is 200,300")
a.splice(2,0,200,300)
console.log(a)
console.log("Remove 4th index element")
a.splice(4,1)
console.log(a)
console.log(" To remove 3rd index  of 2 element")
a.splice(3,2)
console.log(a)
console.log(" To replce 2nd index element 500")
a.splice(2,1,500)
console.log(a)
console.log(" To replce and add last index element")
console.log("Length of an array="+a.length)
a.splice(a.length-1,1,700,1000)
console.log(a)

console.log(" To replce and add last index element -1")
console.log("Length of an array="+a.length)
a.splice(-1,0,900)
console.log(a)



console.log("*************Slice Method*******************")
let ar:string[]=['Core Java',"Advance Java","Spring Boot",'Angular 12','JSP','Jenkings',"Docker","AWS"];
console.log("1.Index start with 0 to 7")
let tmp=ar.slice(0,7);
console.log(tmp)
console.log("2.Index start with 2 to 5")
let tmp1=ar.slice(2,5);
console.log(tmp1)
console.log("3.Index start with 2")
let tmp2=ar.slice(2);
console.log(`Copies Array ${tmp2}`)
console.log("4.Index start with -1")
let tmp3=ar.slice(-1);
console.log(`Copies Array: ${tmp3}`)

console.log("5.Index start with -3 to -1")
let tmp4=ar.slice(-3,0-1);
console.log(`Copies Array: ${tmp4}`)

