//
let jsonobj={
    id:4,
    fname:"snehal",
    "lname":'wakchaure',
    cgpa:9.5
}
console.log(jsonobj);
console.log("************************1.Using dot operator*************************")
console.log(`First Name::${jsonobj.fname}
             Last Name ::${jsonobj.lname}
             ID::${jsonobj.id}
             CGPA::${jsonobj.cgpa}`)

console.log("************************1.Using square operator*************************")
console.log(`First Name::${jsonobj["fname"]}
             Last Name ::${jsonobj["lname"]}
             ID::${jsonobj["id"]}
             CGPA::${jsonobj["cgpa"]}`)