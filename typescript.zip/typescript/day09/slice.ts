console.log("**************Slice method************************")
let a:any[]=[12,'Core Java',78.90,true,"SSS",800,90];
console.log("1.start to end all")
a.slice(0,0)
console.log(a)
a.slice(1,0)
console.log(a)
a.slice(1,4,600)
console.log(a)