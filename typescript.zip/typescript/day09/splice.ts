console.log("*************Splice Method*******************")
let ar:string[]=['Core Java',"Advance Java","Spring Boot",'Angular 12','JSP','Jenkings',"Docker","AWS"];
let tmp=ar.splice(1,7);
console.log(tmp)

