"use strict";
exports.__esModule = true;
var employeedetails_1 = require("./employeedetails");
var empobj = new employeedetails_1.empdetails("sss", "aaa", 7877);
empobj.display();
