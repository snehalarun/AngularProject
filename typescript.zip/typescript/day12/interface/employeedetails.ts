import {employee} from './employee'
export class empdetails implements employee
{
    fname:string;
    lname:string;
    salary:number;
    constructor(f:string,l:string,sal:number){
        this.fname=f;
        this.lname=l;
        this.salary=sal;
    }

    display()
    {
        console.log(`
        ------------------Employee Details-----------------
        First Name=>${this.fname}
        Last Name=>${this.lname}
        Salary=>${this.salary}`)
    }

}