"use strict";
exports.__esModule = true;
exports.empdetails = void 0;
var empdetails = /** @class */ (function () {
    function empdetails(f, l, sal) {
        this.fname = f;
        this.lname = l;
        this.salary = sal;
    }
    empdetails.prototype.display = function () {
        console.log("\n        ------------------Employee Details-----------------\n        First Name=>".concat(this.fname, "\n        Last Name=>").concat(this.lname, "\n        Salary=>").concat(this.salary));
    };
    return empdetails;
}());
exports.empdetails = empdetails;
