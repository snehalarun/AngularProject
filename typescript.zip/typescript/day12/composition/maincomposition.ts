import { empdetails } from "./employeedetails";
let empobj=new empdetails("sss","aaa",7877,"developer");
empobj.display();