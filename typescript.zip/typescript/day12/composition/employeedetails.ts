import { department } from './department';
import {employee} from './employee'
export class empdetails implements employee
{
    fname:string;
    lname:string;
    salary:number;
    dept:department
    constructor(f:string,l:string,sal:number,role:string){
        this.fname=f;
        this.lname=l;
        this.salary=sal;
        this.dept=new department(role);
    }

    display()
    {
        console.log(`
        ------------------Employee Details-----------------
        First Name=>${this.fname}
        Last Name=>${this.lname}
        Salary=>${this.salary}
        Department=>${this.dept.getRole()}`)
    }

}