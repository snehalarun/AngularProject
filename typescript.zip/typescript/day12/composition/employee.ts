export interface employee{
    fname:string;
    lname:string;
    fullname?:string;

    display()
}