"use strict";
exports.__esModule = true;
exports.department = void 0;
var department = /** @class */ (function () {
    function department(r) {
        this.role = r;
    }
    department.prototype.getRole = function () {
        return this.role;
    };
    department.prototype.setRole = function (r) {
        this.role = r;
    };
    return department;
}());
exports.department = department;
