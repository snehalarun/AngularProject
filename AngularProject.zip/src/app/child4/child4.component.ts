import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child4',
  templateUrl: './child4.component.html',
  styleUrls: ['./child4.component.css']
})
export class Child4Component implements OnInit {

  @Output() childStrEvent= new EventEmitter();
  strData:string="Snehal Wakchaure of Angular 12 Developer";
  constructor() { }

  ngOnInit(): void {
    this.childStrEvent.emit(this.strData);
  }
  onSend(){
    this.childStrEvent.emit(this.strData);
  }


}
