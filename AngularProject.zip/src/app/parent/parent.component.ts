import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  strData:string="Hopes so you are enjoying Angular12 Module "
  json:any=[
    {
      name:'snehal',
      degree:'MCA',
      cgpa:9.16
    },
    {
      name:'siya',
      degree:'BCA',
      cgpa:9.0
    },

    {
      name:'shruti',
      degree:'MCM',
      cgpa:9.16
    },
    {
      name:'komal',
      degree:'MCA',
      cgpa:9.16
    },
    {
      name:'piya',
      degree:'ME',
      cgpa:9.3
    }

  ]
  jsonobj={
    id:66,
    fname:'Snehal',
    lname:'Wakchaure'
  }
  arrobj:any[]=[23,'snehal',"Wakchaure",98.89,"7884.9009",'45.67',343342.233];
  ChildStrDataReceived:string='';
  ChildArrObjReceived:any[]=[];
  ChildJsonObjReceived:any='';
  constructor() { }

  ngOnInit(): void {
  }

}
