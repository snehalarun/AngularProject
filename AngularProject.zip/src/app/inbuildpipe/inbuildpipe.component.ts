import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inbuildpipe',
  templateUrl: './inbuildpipe.component.html',
  styleUrls: ['./inbuildpipe.component.css']
})
export class InbuildpipeComponent implements OnInit {


  str:string="Welcome to Angular12 module with snehal wakchAURE";
  num:number=-452.78959;
  mydate=new Date();
  constructor() { }

  ngOnInit(): void {
  }

}
