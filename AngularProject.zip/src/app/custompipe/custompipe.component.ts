import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custompipe',
  templateUrl: './custompipe.component.html',
  styleUrls: ['./custompipe.component.css']
})
export class CustompipeComponent implements OnInit {

  strdetails:string="Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit officia, omnis voluptatibus esse, in corrupti quae autem necessitatibus ad exercitationem itaque nulla blanditiis, ullam repudiandae odit unde ducimus quibusdam debitis?Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit officia, omnis voluptatibus esse, in corrupti quae autem necessitatibus ad exercitationem itaque nulla blanditiis, ullam repudiandae odit unde ducimus quibusdam debitis?";
  constructor() { }

  ngOnInit(): void {
  }

}
