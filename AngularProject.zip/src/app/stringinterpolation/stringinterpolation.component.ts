import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stringinterpolation',
  templateUrl: './stringinterpolation.component.html',
  styleUrls: ['./stringinterpolation.component.css']
})
export class StringinterpolationComponent implements OnInit {

  name:string='Snehal Wakchaure';
  imgUrl:string='../../assets/download.jpg';
  imgUrl1:string='../../assets/_DSC0973.JPG';



  constructor() { }

  ngOnInit(): void {
  }

}
