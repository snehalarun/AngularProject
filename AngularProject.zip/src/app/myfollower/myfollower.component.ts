import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myfollower',
  templateUrl: './myfollower.component.html',
  styleUrls: ['./myfollower.component.css']
})
export class MyfollowerComponent implements OnInit {

  
  constructor() { }

  ngOnInit(): void {
  }

}
