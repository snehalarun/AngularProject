import { Component,Output, OnInit, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child6',
  templateUrl: './child6.component.html',
  styleUrls: ['./child6.component.css']
})
export class Child6Component implements OnInit {

  @Output() ChildJsonObjEvent=new EventEmitter();
  jsonobj={
      id:102,
      name:'refrigerator',
      price:'30000',
      qty:1
    }
  constructor() { }

  onSend(){
    this.ChildJsonObjEvent.emit(this.jsonobj);
}
  ngOnInit(): void {
  }

}
