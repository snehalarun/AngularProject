import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-for-directive',
  templateUrl: './for-directive.component.html',
  styleUrls: ['./for-directive.component.css']
})
export class ForDirectiveComponent implements OnInit {

  course:string[]=["Core Java","Advance java","Spring","JSP","Angular","Jenkings","Docker"];
  arrobj=[
   {
      name:'Motorola',
      price:'30000',
      qty:1
    },
    {
      name:'Samsung',
      price:'25000',
      qty:2
    },
    {
      name:'OnePlus',
      price:'35000',
      qty:3
    },
    {
      name:'Realme',
      price:'30000',
      qty:4
    }
  ]
  selected:string='';
  constructor() { }

  
  ngOnInit(): void {
  }
  onMouseOver(item:any){
    console.log("On Mouse Over Event Occur....");
    this.selected=item.name;
  }

  onMouseOut(){
    //console.log("On Mouse Out Event Occur....");
    this.selected=' ';
  }
}
