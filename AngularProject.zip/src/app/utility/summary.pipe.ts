import { Pipe, PipeTransform } from "@angular/core";
@Pipe({
    name:'summary'

})
export class SummaryPipe implements  PipeTransform{
    transform(value: any,start:number=0,end:number=20) {
        let tmp=(<String> value)
       // return (tmp.substring(0,20)+"...");
       return (tmp.substring(start,end));
        
    }
}