export class CourseService{
    private course:string[]=[
        'core Java','Advanced Java','JSP','Angular','Jenkings','AWS','Docker'
    ]
    getCourse(){
        return this.course;
    }
}