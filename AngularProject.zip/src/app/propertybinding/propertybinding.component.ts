import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-propertybinding',
  templateUrl: './propertybinding.component.html',
  styleUrls: ['./propertybinding.component.css']
})
export class PropertybindingComponent implements OnInit {

  name:string="snehal";
  ishidden:boolean=false;
  imgurl:string='../../assets/ganpati.jfif';
  constructor() { }

  ngOnInit(): void {
  }

}
