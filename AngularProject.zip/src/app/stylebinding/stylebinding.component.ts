import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stylebinding',
  templateUrl: './stylebinding.component.html',
  styleUrls: ['./stylebinding.component.css']
})
export class StylebindingComponent implements OnInit {
  mycolor:string='red';
  rating:number=4;

  jsonobj={
    color:'purple ',
    fontsize:"32pv",
    'font-family':'Impact, Haettenschweiler,Arial Narrow Bold,san-serif'
  }
  constructor() { }

  ngOnInit(): void {
  }

}
