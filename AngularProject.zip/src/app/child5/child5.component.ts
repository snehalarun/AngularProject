import { Component,Output ,OnInit, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child5',
  templateUrl: './child5.component.html',
  styleUrls: ['./child5.component.css']
})
export class Child5Component implements OnInit {

  
  @Output() ChildArrObjEvent=new EventEmitter();

 strData:string='Sumit Raokhande of Angular 12 Trainer';
 arrobj=[
   {
     name:'Motorola',
     price:'30000',
     qty:1
   },
   {
     name:'Samsung',
     price:'25000',
     qty:2
   },
   {
     name:'OnePlus',
     price:'35000',
     qty:3
   },
   {
     name:'RealMe',
     price:'20000',
     qty:4
   }
 ];



  constructor() { }

  onSend(){
    this.ChildArrObjEvent.emit(this.arrobj);
}

  ngOnInit(): void {
  }

}
