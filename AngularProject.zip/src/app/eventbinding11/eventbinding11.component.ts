import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eventbinding11',
  templateUrl: './eventbinding11.component.html',
  styleUrls: ['./eventbinding11.component.css']
})
export class Eventbinding11Component implements OnInit {

  result!:number;
  name:string='';
  constructor() { }

  onChange(){
    console.log("Change event occur....")
  }
  onChange1(myname:any){
    console.log("Change event occur....")
    myname.style.background="green";
    myname.style.color="white";
    console.log(myname.value);
    }
    onKeyUp(){
      console.log("Key up event occur....")
    }
    onKeyDown(){
      console.log("Key down  event occur....")
    }
  ngOnInit(): void {
  }

}
