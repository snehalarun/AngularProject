import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Eventbinding11Component } from './eventbinding11.component';

describe('Eventbinding11Component', () => {
  let component: Eventbinding11Component;
  let fixture: ComponentFixture<Eventbinding11Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Eventbinding11Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Eventbinding11Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
